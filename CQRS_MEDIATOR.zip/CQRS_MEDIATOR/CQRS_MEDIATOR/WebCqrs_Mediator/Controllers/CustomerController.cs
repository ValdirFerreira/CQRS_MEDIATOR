﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebCqrs_Mediator.Domain.Commands.Requests;
using WebCqrs_Mediator.Domain.Commands.Responses;
using WebCqrs_Mediator.Domain.Handlers;
using WebCqrs_Mediator.Models;

namespace WebCqrs_Mediator.Controllers
{

    // install MediatR ( via nugget )

    // install MediatR.Extensions.Microsoft.DependencyInjection para o Startup ( via nugget )

    [ApiController]
    [Route("v1/customers")]
    public class CustomerController : ControllerBase
    {

        [HttpPost]
        [Route("")]

        public async Task<CreateCustomerResponse> Create([FromServices]IMediator mediator, [FromBody] CreateCustomerRequest command)
        {
            return await mediator.Send(command);
        }
        //public CreateCustomerResponse Create([FromServices]ICreateCustomerHandler handler, [FromBody] CreateCustomerRequest command)
        //{
        //    return handler.Handle(command);
        //}

    }
}
