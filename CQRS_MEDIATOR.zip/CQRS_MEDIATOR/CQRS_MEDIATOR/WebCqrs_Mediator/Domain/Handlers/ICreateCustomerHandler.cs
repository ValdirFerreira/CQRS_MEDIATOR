﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebCqrs_Mediator.Domain.Commands.Requests;
using WebCqrs_Mediator.Domain.Commands.Responses;

namespace WebCqrs_Mediator.Domain.Handlers
{
    public interface ICreateCustomerHandler
    {
        CreateCustomerResponse Handle(CreateCustomerRequest request);
    }
}
