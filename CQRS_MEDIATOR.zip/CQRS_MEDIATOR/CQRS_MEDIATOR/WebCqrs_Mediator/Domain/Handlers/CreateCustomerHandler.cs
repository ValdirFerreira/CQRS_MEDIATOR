﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using WebCqrs_Mediator.Domain.Commands.Requests;
using WebCqrs_Mediator.Domain.Commands.Responses;

namespace WebCqrs_Mediator.Domain.Handlers
{
    public class CreateCustomerHandler : IRequestHandler<CreateCustomerRequest, CreateCustomerResponse> //ICreateCustomerHandler
    {
        //ICustomerRepository _repository;
        //IEmailService _emailService;

        public CreateCustomerResponse Handle(CreateCustomerRequest request)
        {
            // verifica se o cliente já está cadastrado
            // valida
            // insere cliente//
            // envia cliente 

            return new CreateCustomerResponse
            {
                Id = Guid.NewGuid(),
                Email = "Valdir@valdir.com",
                Name = "Valdir Ferreira",
                Date = DateTime.Now
            };
        }

        public Task<CreateCustomerResponse> Handle(CreateCustomerRequest request, CancellationToken cancellationToken)
        {
            // verifica se o cliente já está cadastrado
            // valida
            // insere cliente//
            // envia cliente 

            var result = new CreateCustomerResponse
            {
                Id = Guid.NewGuid(),
                Email = "Valdir@valdir.com",
                Name = "Valdir Ferreira",
                Date = DateTime.Now
            };

            return Task.FromResult(result);
        }
    }
}
